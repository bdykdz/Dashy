package com.example.art.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        model.addAttribute("message", "Welcome Admin");
        return "admin-dashboard";
    }

    @GetMapping("/user/dashboard")
    public String userDashboard(Model model) {
        model.addAttribute("message", "Welcome User");
        return "user-dashboard";
    }
}
